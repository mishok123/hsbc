﻿/* SPMS*/

// this function is used to delete biodata
function CheckForDelete(vType) {
    if (confirm("Are you sure you want to delete " + vType)) {
        return true;
    }
    else {
        return false;
    }
}

//open and check Search popup..
function openIssueSearchPopup(objName) {
    var oTxtRegNo = document.getElementById(objName);
    if (oTxtRegNo != null) {
        if (oTxtRegNo.value != null && oTxtRegNo.value != "") {
            return true;
        }
        else {
            IssueSearchPopupReturnTrue();
            CloseErrorPanel();
            return false;
        }
    } else {
        IssueSearchPopupReturnTrue();
        CloseErrorPanel();
        return false;
    }
}

function openDuplicateIssueSearchPopup(objName) {
    var oTxtRegNo = document.getElementById(objName);
    if (oTxtRegNo != null) {
        if (oTxtRegNo.value != null && oTxtRegNo.value != "") {
            return true;
        }
        else {
            StopPaymentSearchPopupReturnTrue('3.2');
            CloseErrorPanel();
            return false;
        }
    } else {
        StopPaymentSearchPopupReturnTrue('3.2');
        CloseErrorPanel();
        return false;
    }
}

function openStopPaymentSearchPopup(objName) {
    var oTxtRegNo = document.getElementById(objName);
    if (oTxtRegNo != null) {
        if (oTxtRegNo.value != null && oTxtRegNo.value != "") {
            CloseErrorPanel();
            return true;
        }
        else {
            StopPaymentSearchPopupReturnTrue('3.2');
            CloseErrorPanel();
            return false;
        }
    } else {
        StopPaymentSearchPopupReturnTrue('3.2');
        CloseErrorPanel();
        return false;
    }
}

function openLienMarkSearchPopup(objName) {
    var oTxtRegNo = document.getElementById(objName);
    if (oTxtRegNo != null) {
        if (oTxtRegNo.value != null && oTxtRegNo.value != "") {
            CloseErrorPanel();
            return true;
        }
        else {
            LienMarkSearchPopupReturnTrue('1.2');
            CloseErrorPanel();
            return false;
        }
    } else {
        LienMarkSearchPopupReturnTrue('1.2');
        CloseErrorPanel();
        return false;
    }
}


function ShowProgressStatus(vID) {
    var oLbl = document.getElementById(vID);
    if (oLbl != null) {
        oLbl.innerHTML = "Searching...";
        oLbl.style.display = "block";
    }
}
function HideProgressStatus(vID) {
    var oLbl = document.getElementById(vID);
    if (oLbl != null) {
        oLbl.innerHTML = "Search Completed.";
    }
}

function NotDoneYet() {
    alert("It has not compeleted..");
    return false;
}

function CloseErrorPanel() {
    var divErrorPanel = document.getElementById('divErrorPanel');
    if (divErrorPanel != null) {
        divErrorPanel.style.display = "none";
        window.scroll(0, 0);
    }
}

function OpenErrorPanel(sErrorList, vPanelType) {
    var divErrorPanel = document.getElementById('divErrorPanel');
    if (sErrorList.length > 0) {
        var errorList = document.getElementById('divErrorList');
        errorList.innerHTML = "<ul>" + sErrorList + "</ul>";
        divErrorPanel.style.display = "block";
        window.scroll(0, 0);
        return false;
    }
    else {        
        divErrorPanel.style.display = "none";
        if (vPanelType != "") {
            window.scroll(0, 0);
            MsgPopupReturnTrue(vPanelType);
        }
        return true;
    }
}

function OpenErrorPanelWithoutPopUp(sErrorList) {
    var divErrorPanel = document.getElementById('divErrorPanel');
    if (sErrorList.length > 0) {
        var errorList = document.getElementById('divErrorList');
        errorList.innerHTML = "<ul>" + sErrorList + "</ul>";
        divErrorPanel.style.display = "block";
        window.scroll(0, 0);
        return false;
    }
    else {        
        divErrorPanel.style.display = "none";        
        return true;
    }
}

function ResetData(objId) {
    var tmpObj = document.getElementById(objId);
    if (tmpObj.type == "text" || tmpObj.type == "hidden" || tmpObj.type == "textarea") {
        tmpObj.value = "";
    }
    else if (tmpObj.type == "select-one") {
        tmpObj.selectedIndex = 0;
        $("#objId option").remove();
    }
    else if (tmpObj.type == "checkbox") {
        tmpObj.checked = false;
    }
    else if (tmpObj.type == "radio") {
        $("input:radio").removeAttr("checked");
    }
}

function ResetUserDetails() {
    ResetData('ctl00_cphDet_ucUserDet_txtCheckerId');
    ResetData('ctl00_cphDet_ucUserDet_txtCheckerComments');
    ResetData('ctl00_cphDet_ucUserDet_txtMakeDate');
    ResetData('ctl00_cphDet_ucUserDet_txtCheckDate');

    var currentDt = new Date();
    var mm = currentDt.getMonth() + 1;
    mm = (mm < 10) ? '0' + mm : mm;
    var dd = currentDt.getDate();
    dd = (dd < 10) ? '0' + dd : dd;
    var yyyy = currentDt.getFullYear();
    var date = dd + '/' + mm + '/' + yyyy;
    var makeDate = document.getElementById('ctl00_cphDet_ucUserDet_txtMakeDate')
    makeDate.value = date;
}




function BtnSetStatus(objID, btnStatus) {
    var tmpObj = document.getElementById(objID);

    if (tmpObj != null && btnStatus == true) {
        tmpObj.className = "ButtonAsh";
        tmpObj.disabled = false;
    } else {
        tmpObj.className = "ButtonAshInActive";
        tmpObj.disabled = true;
    }
}

function floatNumber(e) {
    var pValue = e.currentTarget.value;
    if (pValue != "undefined") {
        var nValue = pValue + String.fromCharCode(e.charCode);
    } else {
        var nValue = String.fromCharCode(e.charCode);
    }
    var totalDot = nValue.split('.');
    if (totalDot.length > 2) {
        return false;
    }
    else if (e.which != 8 && e.which != 0 && e.which != 46 && (e.which < 48 || e.which > 57)) {
        return false;
    }
    else {
        return true;
    }
}

function intNumber(e) {
    if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        return false;
    }
}
function textPhoneFax(e) {
    if (e.which != 8 && e.which != 43 && e.which != 45 && e.which != 32 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        return false;
    }
}


function textInput(e) {
    if (e.which != 8 && e.which != 0 && e.which != 32 && (e.which < 65 || e.which > 90) && (e.which < 97 || e.which > 122)) {
        return false;
    }
}


function CheckIssueStatus(obj) {
    var d1 = document.getElementById("ctl00_cphDet_SIssue_chklIssueStatus_0");
    var d2 = document.getElementById("ctl00_cphDet_SIssue_chklIssueStatus_1");
    var d3 = document.getElementById("ctl00_cphDet_SIssue_chklIssueStatus_2");
    if (obj.value == "1") {
        d1.checked = false;
        d2.checked = false;
        d3.checked = false;
    }
    else {
        d1.checked = true;
        d2.checked = true;
        d3.checked = true;
    }
}


function RbChangeColor(objName) {

    var rblListType = document.getElementsByName(objName.name);
    if (rblListType != null) {
        for (var j = 0; j < rblListType.length; j++) {
            if (rblListType[j].checked == true) {
                rblListType[j].nextSibling.style.color = '#EE8927';
                rblListType[j].nextSibling.style.fontWeight = 'bold';
            } else {
                rblListType[j].nextSibling.style.color = '#000000';
                rblListType[j].nextSibling.style.fontWeight = '';
            }
        }
    }
}

function ChkChangeColor(objCtrl) {
    if (objCtrl == null) {
        return;
    }
    objCtrl.parentNode.style.color = objCtrl.checked ? '#EE8927' : '';
    objCtrl.parentNode.style.fontWeight = objCtrl.checked ? 'bold' : '';
}

var currentlyActiveInputRef = false;
var currentlyActiveInputClassName = false;
function highlightActiveInputWithObj(obj) {
    if (currentlyActiveInputRef) {
        currentlyActiveInputRef.className = currentlyActiveInputClassName;
    }
    currentlyActiveInputClassName = obj.className;
    obj.className = 'inputHighlighted';
    currentlyActiveInputRef = obj;
}
function blurActiveInputWithObj(obj) {
    obj.className = currentlyActiveInputClassName;
    // only Validate Date
    if (obj.accessKey == "V") {
        ValidateDate(obj);
    }
    // Validate Date + Advance date
    else if (obj.accessKey == "A") {
        ValidateDate(obj);
        AdvanceDate(obj);
    }
}
/* SPMS*/



function CheckListDataFilter(objDDL) {
    var sItems = "";
    var objBase = objDDL.id;
    var end = (objBase.lastIndexOf("_"));
    var sOriginalName = objBase.substr(end, objBase.length);
    var vName = objBase.substr(0, end - 1);
    for (var i = 0; i < objDDL.options.length + 2; i++) {
        var vN = vName + i + sOriginalName;
        if (objDDL.id != vN) {
            var ddlElement = document.getElementById(vN);
            if (ddlElement == null) {
            }
            else {
                if (ddlElement.options[ddlElement.selectedIndex].text != "") {
                    sItems += "~" + ddlElement.options[ddlElement.selectedIndex].text;
                }
            }
        }
    }
    if (sItems.search(objDDL.options[objDDL.selectedIndex].text) > 0) {
        alert("You have already selected this option. Please select other option!");
        objDDL.selectedIndex = 0;
    }
}



// from validation ...
var isEmailProb = -1;  //0. -1 for nothing,  1. 1 for ok , 2. 2 for empty 3. 3 for Incorrect
function CheckAllRequiredFields(objControlType, objControlID) {
    isEmailProb = -1;
    var status = "";
    if (objControlType == "TextBox") {
        var txtPropertyName = document.getElementById(objControlID).value;
        if (txtPropertyName != null) {
            if (txtPropertyName.length == 0 || txtPropertyName == "") {
                status = false;
            }
            else {
                status = true;
            }
        }
    }
    else if (objControlType == "CheckBox") {
        var cblListType = document.getElementById(objControlID);
        if (cblListType != null) {
            var cblListTypeCount = cblListType.getElementsByTagName("input");
            var iSBMlListTypeExist = 0;
            for (var i = 0; i < cblListTypeCount.length; i++) {
                if (cblListTypeCount[i].checked == true) {
                    iSBMlListTypeExist = 1;
                    status = true;
                }
            }
            if (iSBMlListTypeExist == 0) {
                status = false;
            }
        }
    }
    else if (objControlType == "DropDownList") {
        var ddlControl = document.getElementById(objControlID);

        if (ddlControl != null) {
            if (ddlControl.selectedIndex == -1) {
                status = false;
            }
            else {
                if (ddlControl.options[ddlControl.selectedIndex].value == "0" || ddlControl.options[ddlControl.selectedIndex].value == "") {
                    status = false;
                }
                else {
                    status = true;
                }
            }
        }
    }
    else if (objControlType == "Email") {
        isEmailProb = 1;
        var txtEmail = document.getElementById(objControlID).value;
        if (txtEmail != null) {
            if (txtEmail.length == 0 || txtEmail == "") {
                status = false;
                isEmailProb = 2;
            } else {
                var vEmail = checkEmail(objControlID, false);
                if (vEmail == false) {
                    status = false;
                    isEmailProb = 3;
                }
                else {
                    status = true;
                    isEmailProb = 1;
                }
            }
        }
    }
    else if (objControlType == "Url") {
        var tomatch = /http:\/\/[A-Za-z0-9\.-]{3,}\.[A-Za-z]{3}/
        var txtUrl = document.getElementById(objControlID).value;
        if (txtUrl != null) {
            if (txtUrl.length == 0 || txtUrl == "") {
                status = false;
            } else {
                if (tomatch.test(txtUrl)) {
                    status = true;
                }
                else {
                    status = false;
                }
            }
        }
    }
    return status;
}

function RequiredData(vObjId, vType, vMsg) {
    var sErrorList = "";
    var obj = document.getElementById(vObjId);
    obj.className = 'textInput';
    var vStatus = CheckAllRequiredFields(vType, vObjId);
    if (vStatus == false) {
        if (vType == "Email") {
            if (isEmailProb == "2") {
                sErrorList += "<li>" + vMsg + "</li>";
            }
            else if (isEmailProb == "3") {
                sErrorList += "<li>Incorrect email address</li>";
            }
        } else {
            sErrorList += "<li>" + vMsg + "</li>";
        }
        if (obj != null) {
            obj.className = 'errorInputHighlightedError';
        }
    }
    return sErrorList;
}

function AddingCommas(nStrTmp) {
    // var nStrTmp = obj.value;
    var nStr = nStrTmp.toString().replace(/,/g, '');
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}

function validate(email) {
    var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    return reg.test(email);
}
function trim(str) {
    var str = str.replace(/^\s\s*/, ''),
		ws = /\s/,
		i = str.length;
    while (ws.test(str.charAt(--i)));
    return str.slice(0, i + 1);
}

function checkEmail(objId, isMessageShow) {
    isEmailProb = false;
    var status = true;
    var i = 0;
    var emails = document.getElementById(objId).value.split(",");
    for (i = 0; i < emails.length; i++) {
        if (!validate(trim(emails[i]))) {
            if (isMessageShow == true) {
                alert("Incorrect email address.");
                isEmailProb = 3;
            }
            status = false;
            break;
        }
    }
    if (status == false) {
        isEmailProb = 3;
        return false;
    }
    else {
        isEmailProb = 1;
        return true;
    }
}

function GetRandomNumber() {
    var randomnumber = Math.floor(Math.random() * 11);
    return randomnumber;

}




// ValidateDate...
function ValidateDate(objDate) {
    var dateValue = objDate.value;
    if (dateValue != "__/__/____") {
        var dataArray = dateValue.split('/');
        if (dataArray.length == 3) {
            var vDay = dataArray[0];
            var vMonth = dataArray[1];
            var vYear = dataArray[2];

            if (
                vDay >= 1 && vDay <= 31 &&
                vMonth >= 1 && vMonth <= 12 &&
                vYear >= 1900 && vYear <= 2050
           ) {
                var vTotalDays = 0;
                if (vMonth == '2' && (vYear % 4) == 0 && (vYear % 100) != 0)
                    vTotalDays = 29;
                else if (vMonth == '2' && (vYear % 400) == 0 && (vYear % 100) != 0)
                    vTotalDays = 29;
                else if (vMonth == '2')
                    vTotalDays = 28;
                else if (vMonth == '4' || vMonth == '6' || vMonth == '9' || vMonth == '11')
                    vTotalDays = 30;
                else
                    vTotalDays = 31;

                if (vDay <= vTotalDays) {
                }
                else {
                    //objDate.focus();
                    alert("Invalid date format (Should be [dd/mm/yyyy]) or out of range");
                    objDate.value = "";
                    return false;
                }
            }
            else {
                //objDate.focus();
                alert("Invalid date format (Should be [dd/mm/yyyy]) or out of range");
                objDate.value = "";
                return false;
            }
        }
    }
}

function FutureDate(obj) {
    var today = new Date();
    var dateValue = obj.value;
    if (dateValue != "__/__/____") {
        var dataArray = dateValue.split('/');
        if (dataArray.length == 3) {
            var vDay = dataArray[0];
            var vMonth = dataArray[1];
            var vYear = dataArray[2];
            var dayobj = new Date(vYear, vMonth - 1, vDay);
            if (dayobj > today) {
            } else {
                alert("Cannot be a future date.!");
                obj.value = "";
            }
        }
    }
}

function PastDate(obj) {
    var today = new Date();
    var dateValue = obj.value;
    if (dateValue != "__/__/____") {
        var dataArray = dateValue.split('/');
        if (dataArray.length == 3) {
            var vDay = dataArray[0];
            var vMonth = dataArray[1];
            var vYear = dataArray[2];
            var dayobj = new Date(parseInt(vYear) + 18, vMonth - 1, vDay);
            if (dayobj <= today) {
            } else {
                alert("Invalid date range. Not 18 years.!");
                obj.value = "";
            }
        }
    }
}

/* active input control */


function highlightActiveInput() {
    if (currentlyActiveInputRef) {
        currentlyActiveInputRef.className = currentlyActiveInputClassName;
    }
    currentlyActiveInputClassName = this.className;
    this.className = 'inputHighlighted';
    currentlyActiveInputRef = this;
}

function blurActiveInput() {
    this.className = currentlyActiveInputClassName;

    // "P" -> past date
    if (this.accessKey == "P") {
        ValidateDate(this);
        PastDate(this);
    }

    // "E" -> Expiry date is to be default as SMI last date.. (Loan Update Page)
    else if (this.accessKey == "E") {
        var oEMILastDate = document.getElementById("ctl00_ASPxRoundPanel2_cphDetails_tabContainerPLDisbursement_tabPaneLoanDetails_loanDetailsDisbursementTemplate_txtEMILastDate");
        var oExpiryDate = document.getElementById("ctl00_ASPxRoundPanel2_cphDetails_tabContainerPLDisbursement_tabPaneLoanDetails_loanDetailsDisbursementTemplate_txtExpiryDate");
        if (oEMILastDate != null && oExpiryDate != null) {
            oExpiryDate.value = oEMILastDate.value;
        }
    }

    // "F" -> future data..
    else if (this.accessKey == "F") {
        ValidateDate(this);
        FutureDate(this);
    }

    // "O" -> PL discode
    else if (this.accessKey == "O") {
        var vDiscode = document.getElementById("ctl00_ASPxRoundPanel2_cphDetails_tabContainerPLDisbursement_tabPaneLoanDetails_loanDetailsDisbursementTemplate_txtPLDiscCode");
        if (vDiscode != null) {
            var txtPLPDCReceived = document.getElementById("ctl00_ASPxRoundPanel2_cphDetails_tabContainerPLDisbursement_tabPaneLoanDetails_loanDetailsDisbursementTemplate_txtPLPDCReceived");
            if (vDiscode.value == "D1") {

                if (txtPLPDCReceived != null) {
                    txtPLPDCReceived.disabled = false;
                }
            } else {
                if (txtPLPDCReceived != null) {
                    txtPLPDCReceived.value = "";
                    txtPLPDCReceived.disabled = true;
                }
            }
        }
    }
    // "D" -> Number convert to string......
    else if (this.accessKey == "D") {
        ValidateDate(this);
        //FutureDate(this);
        //toWords(this.value, "ctl00_ASPxRoundPanel2_cphDetails_tabContainerPLDisbursement_tabPaneLoanDetails_loanDetailsDisbursementTemplate_txtLimitInWord");
        NumberToWords(this.value, "ctl00_ASPxRoundPanel2_cphDetails_tabContainerPLDisbursement_tabPaneLoanDetails_loanDetailsDisbursementTemplate_txtLimitInWord");
    }
    else if (this.accessKey == "" && this.title == "Date") {
        ValidateDate(this);
    }
}
function initInputHighlightScript() {
    var tags = ['INPUT', 'TEXTAREA'];
    for (tagCounter = 0; tagCounter < tags.length; tagCounter++) {
        var inputs = document.getElementsByTagName(tags[tagCounter]);
        for (var no = 0; no < inputs.length; no++) {
            if (inputs[no].className && inputs[no].className == 'doNotHighlightThisInput')
                continue;
            if (inputs[no].tagName.toLowerCase() == 'textarea' ||
                  (inputs[no].tagName.toLowerCase() == 'input' && inputs[no].type.toLowerCase() == 'text')
               ) {
                inputs[no].onfocus = highlightActiveInput;
                inputs[no].onblur = blurActiveInput;
            }
        }
    }
}

//by Istiak
function AdvanceDate(obj) {
    var today = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());
    var dateValue = obj.value;
    if (dateValue != "__/__/____") {
        var dataArray = dateValue.split('/');
        if (dataArray.length == 3) {
            var vDay = dataArray[0];
            var vMonth = dataArray[1];
            var vYear = dataArray[2];
            var dayobj = new Date(vYear, vMonth - 1, vDay);
            if (dayobj > today) {
                alert("Cannot be an advanced date.!");
                obj.value = "";
            }
        }
    }
}


// Numbers to Words
// ref.. to convert C# code..

//*******************************************************************************************************
// in old format...
var th = ['', 'THOUSAND', 'MILLION', 'BILLION', 'TRILLION'];
var dg = ['ZERO', 'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX', 'SEVEN', 'EIGHT', 'NINE'];
var tn = ['TEN', 'ELEVEN', 'TWELVE', 'THIRTEEN', 'FOURTEEN', 'FIFTEEN', 'SIXTEEN', 'SEVENTEEN', 'EIGHTEEN', 'NINETEEN'];
var tw = ['TWENTY', 'THIRTY', 'FORTY', 'FIFTY', 'SIXTY', 'SEVENTY', 'EIGHTY', 'NINETY'];

function toWords(s, toObjId) {
    s = s.toString(); s = s.replace(/[\, ]/g, ''); if (s != parseFloat(s)) return 'not a number';
    var x = s.indexOf('.'); if (x == -1) x = s.length; if (x > 15) return 'too big';
    var n = s.split('');
    var str = '';
    var sk = 0;
    for (var i = 0; i < x; i++) {
        if ((x - i) % 3 == 2) {
            if (n[i] == '1') {
                str += tn[Number(n[i + 1])] + ' '; i++; sk = 1;
            }
            else if (n[i] != 0) {
                str += tw[n[i] - 2] + ' '; sk = 1;
            }
        } else if (n[i] != 0) {
            str += dg[n[i]] + ' ';
            if ((x - i) % 3 == 0) str += 'HUNDRED '; sk = 1;
        }
        if ((x - i) % 3 == 1) {
            if (sk)
                str += th[(x - i - 1) / 3] + ' '; sk = 0;
        }
    }
    if (x != s.length) {
        var y = s.length;
        str += 'point ';
        for (var i = x + 1; i < y; i++)
            str += dg[n[i]] + ' ';
    }
    //return str.replace(/\s+/g, ' ');
    var toObj = document.getElementById(toObjId);
    if (toObj != null) {
        toObj.value = str.replace(/\s+/g, ' ');
    }
}

// in old format...
//************************************************************************************************

// start to ..in new format
//************************************************************************************************
var _smallNumbers = ['ZERO', 'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX', 'SEVEN', 'EIGHT', 'NINE', 'TEN', 'ELEVEN', 'TWELVE', 'THIRTEEN', 'FOURTEEN', 'FIFTEEN', 'SIXTEEN', 'SEVENTEEN', 'EIGHTEEN', 'NINETEEN'];
var _tens = ['', '', 'TWENTY', 'THIRTY', 'FORTY', 'FIFTY', 'SIXTY', 'SEVENTY', 'EIGHTY', 'NINETY'];
var _scaleNumbers = ['', 'HUNDRED', 'THOUSAND', 'LAC', 'CRORE'];

function NumberToWords(number, toObjId) {
    if (number == 0)
        return _smallNumbers[0];
    var digitGroups = [''];
    var positive = number;
    for (var i = 0; i < 5; i++) {
        if (i == 1) {
            digitGroups[i] = Math.floor(parseInt(positive) % 10);
            positive = Math.floor(parseInt(positive) / 10);
        }
        else {
            digitGroups[i] = Math.floor(parseInt(positive) % 100);
            positive = Math.floor(parseInt(positive) / 100);
        }
    }
    var groupText = [''];
    for (var i = 0; i < 5; i++)
        groupText[i] = ThreeDigitGroupToWords(digitGroups[i]);

    var combined = groupText[0];
    var appendAnd;
    appendAnd = (digitGroups[0] > 0) && (digitGroups[0] < 10);
    for (var i = 1; i < 5; i++) {
        if (digitGroups[i] != 0) {
            var prefix = groupText[i] + " " + _scaleNumbers[i];
            prefix += " ";
            combined = prefix + combined;
        }
    }
    if (number < 0)
        combined = "Negative " + combined;


    var toObj = document.getElementById(toObjId);
    if (toObj != null) {
        toObj.value = combined.replace(/\s+/g, ' ');
    }
}

function ThreeDigitGroupToWords(threeDigits) {
    var groupText = "";
    var hundreds = Math.floor(parseInt(threeDigits) / 100);
    var tensUnits = Math.floor(parseInt(threeDigits) % 100);
    if (hundreds != 0) {
        groupText += _smallNumbers[hundreds] + " Hundred ";
        if (tensUnits != 0)
            groupText += "";
    }
    var tens = Math.floor(parseInt(tensUnits) / 10);
    var units = Math.floor(parseInt(tensUnits) % 10);


    if (tens >= 2) {
        groupText += _tens[tens];
        if (units != 0)
            groupText += "" + _smallNumbers[units];
    }
    else if (tensUnits != 0)
        groupText += _smallNumbers[tensUnits];

    return groupText;
}

// end of new format
//************************************************************************************************

function QueryStringValue(vName) {
    var url = window.location.toString();
    url.match(/\?(.+)$/);
    var params = RegExp.$1;
    var params = params.split("&");
    var vPageType = "0";
    for (var i = 0; i < params.length; i++) {
        var tmp = params[i].split("=");
        if (tmp[0] == vName) {
            vPageType = unescape(tmp[1]);
        }
    }
    return vPageType;
}





/* Modal window */
var maskpanel = function() {
    this.divobj;
    this.show = function() {
        if (!document.getElementById("xdivmasking")) {
            var divEle = document.createElement('div');
            divEle.setAttribute("id", "xdivmasking");
            document.body.appendChild(divEle);
            var divSty = document.getElementById("xdivmasking").style;
            divSty.position = "absolute"; divSty.top = "0px"; divSty.left = "0px";
            divSty.zIndex = "46"; divSty.opacity = ".50"; divSty.backgroundColor = "#000";
            divSty.filter = "alpha(opacity=50)";

            var divFram = document.createElement('iframe');
            divFram.setAttribute("id", "xmaskframe");
            document.body.appendChild(divFram);
            divSty = document.getElementById("xmaskframe").style;
            divSty.position = "absolute"; divSty.top = "0px"; divSty.left = "0px";
            divSty.zIndex = "45"; divSty.border = "none"; divSty.filter = "alpha(opacity=0)";
        }

        this.divobj = document.getElementById("xdivmasking");
        this.waitifrm = document.getElementById("xmaskframe");

        var dsh = document.documentElement.scrollHeight;
        var dch = document.documentElement.clientHeight;
        var dsw = document.documentElement.scrollWidth;
        var dcw = document.documentElement.clientWidth;

        var bdh = (dsh > dch) ? dsh : dch;
        var bdw = (dsw > dcw) ? dsw : dcw;

        this.waitifrm.style.height = this.divobj.style.height = bdh + 'px';
        this.waitifrm.style.width = this.divobj.style.width = bdw + 'px';
        this.waitifrm.style.display = this.divobj.style.display = "block";
    };
    this.hide = function() {
        this.waitifrm.style.display = this.divobj.style.display = "none";
    };
}

function showModal(sDivName) {
    divmask = new maskpanel();
    divmask.show();
    var messageDiv = document.getElementById(sDivName);
    messageDiv.style.display = "block";
    messageDiv.style.top = (((document.documentElement.clientHeight / 2) + document.documentElement.scrollTop) - (messageDiv.offsetHeight / 2)) + 'px';
    messageDiv.style.left = (((document.documentElement.clientWidth / 2) + document.documentElement.scrollLeft) - (messageDiv.offsetWidth / 2)) + 'px';
}
function hideModal(sDivName) {
    divmask.hide();
    var messageDiv = document.getElementById(sDivName);
    messageDiv.style.display = "none";
}
/* Modal window */

