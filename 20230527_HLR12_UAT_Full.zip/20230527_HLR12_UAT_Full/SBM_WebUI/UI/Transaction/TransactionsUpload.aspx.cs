﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SBM_BLC1.Common;
using SBM_BLC1.DAL.Claim;
using SBM_BLC1.Entity.Common;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Text;

namespace SBM_WebUI.mp
{
    public partial class TransactionsUpload : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session[Constants.SES_USER_CONFIG] != null)
            {
                if (!Page.IsPostBack)
                {
                    Util.InvalidateSession();
                    InitializeData();
                    //This is for Page Permission
                    CheckPermission chkPer = new CheckPermission();
                    Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];
                    if (!chkPer.CheckPagePermission((System.Web.UI.Control)this.Page, oConfig, (int)Constants.PAGEINDEX_TRANS.SP_ISSUE))
                    {
                        Response.Redirect(Constants.PAGE_ERROR, false);
                    }
                }
            }
            else
            {
                Response.Redirect(Constants.PAGE_LOGIN, false);
            }
        }

        protected void InitializeData()
        {

            txtTransactionDate.Text = DateTime.Today.ToString(Constants.DATETIME_FORMAT);
            txtUploadDate.Text = DateTime.Today.ToString(Constants.DATETIME_FORMAT);

            DataTable dt1 = new DataTable();
            gvTransactionList.DataSource = dt1;
            gvTransactionList.DataBind();

            gvData.DataSource = dt1;
            gvData.DataBind();
        }

        protected void btnUploadFile_Click(object sender, EventArgs e)
        {
            if (ddlFileTpe.SelectedValue == "PI")
            {
                Upload_Profit();
            }
            else
            {
                Upload_Encashment();
            }
        }
        private bool Upload_Profit()
        {
            lFileStatus.Visible = true;
            bool result = false;
            string filePath = FileUpload1.PostedFile.FileName; // getting the file path of uploaded file  
            string filename1 = Path.GetFileName(filePath); // getting the file name of uploaded file  
            string ext = Path.GetExtension(filename1); // getting the file extension of uploaded file  
            string type = System.String.Empty;
            if (!FileUpload1.HasFile)
            {
                lFileStatus.Text = "Please Select File"; //if file uploader has no file selected  
            }
            else
                if (FileUpload1.HasFile)
                {
                    try
                    {
                        switch (ext) // this switch code validate the files which allow to upload only excel file you can change it for any file  
                        {
                            case ".xls":
                                type = "application/vnd.ms-excel";
                                break;
                            case ".xlsx":
                                type = "application/vnd.ms-excel";
                                break;
                        }
                        if (type != System.String.Empty)
                        {
                            StringBuilder sb = new StringBuilder();
                            try
                            {
                                sb.AppendFormat(" Uploading file: {0}", FileUpload1.FileName);

                                //saving the file
                                FileUpload1.SaveAs(System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath + "\\" + FileUpload1.FileName);
                                //Showing the file information
                                sb.AppendFormat("<br/> Save As: {0}", FileUpload1.PostedFile.FileName);
                                sb.AppendFormat("<br/> File type: {0}", FileUpload1.PostedFile.ContentType);
                                sb.AppendFormat("<br/> File length: {0}", FileUpload1.PostedFile.ContentLength);
                                sb.AppendFormat("<br/> File name: {0}", FileUpload1.PostedFile.FileName);

                            }
                            catch (Exception ex)
                            {
                                sb.Append("<br/> Error <br/>");
                                sb.AppendFormat("Unable to save file <br/> {0}", ex.Message);
                                lFileStatus.Text = sb.ToString();
                            }
                            lFileStatus.Text = sb.ToString();

                            //return;

                            filePath = System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath + "\\" + FileUpload1.FileName;

                            //Stream fStream = FileUpload1.PostedFile.InputStream;
                            lFileStatus.ForeColor = System.Drawing.Color.Green;
                            lFileStatus.Text = "File Uploaded Successfully";

                            //Open the Excel file in Read Mode using OpenXml.
                            // Open the document for editing.

                            SpreadsheetDocument doc = SpreadsheetDocument.Open(filePath, false);

                            //Read the first Sheet from Excel file.
                            Sheet sheet = doc.WorkbookPart.Workbook.Sheets.GetFirstChild<Sheet>();

                            //Get the Worksheet instance.
                            Worksheet worksheet = (doc.WorkbookPart.GetPartById(sheet.Id.Value) as WorksheetPart).Worksheet;

                            //Fetch all the rows present in the Worksheet.
                            IEnumerable<Row> rows = worksheet.GetFirstChild<SheetData>().Descendants<Row>();

                            //Create a new DataTable.
                            DataTable dt = new DataTable();

                            //Loop through the Worksheet rows.
                            string sSPTypeID = "";
                            string sPaymentType = "";
                            foreach (Row row in rows)
                            {
                                //Use the first row to add columns to DataTable.
                                if (row.RowIndex.Value == 1)
                                {
                                    dt.Columns.Add("SPTypeID");
                                    dt.Columns.Add("PaymentType");
                                    dt.Columns.Add("RegistrationNo");
                                    dt.Columns.Add("IssueAmount");
                                    dt.Columns.Add("InterestAmount");
                                    dt.Columns.Add("TaxAmount");
                                    dt.Columns.Add("Adjustment");
                                    dt.Columns.Add("PaymentAmount");
                                    //foreach (Cell cell in row.Descendants<Cell>())
                                    //{
                                    //dt.Columns.Add(GetValue(doc, cell));
                                    //}
                                }
                                else
                                {
                                    //Add rows to DataTable.
                                    if (sSPTypeID != "" && sPaymentType != "")
                                    {
                                        dt.Rows.Add();
                                    }
                                    int i = 0;
                                    foreach (Cell cell in row.Descendants<Cell>())
                                    {
                                        switch (GetValue(doc, cell))
                                        {
                                            case "স্কীমের মূল্যমান":
                                                // code block
                                                break;
                                            case "এইচএসবিসি, ঢাকা মেইন অফিস":
                                                // code block
                                                break;
                                            case "মোট  - ৩- মাস অন্তর মুনাফাভিত্তিক সঞ্চয়পত্র  ":
                                                // code block
                                                break;
                                            case "মোট  - পরিবার সঞ্চয়পত্র  ":
                                                // code block
                                                break;
                                            case "মোট  - ৫-বছর মেয়াদী বাংলাদেশ সঞ্চয়পত্র  ":
                                                // code block
                                                break;
                                            case "মোট-এইচএসবিসি, ঢাকা মেইন অফিস":
                                                // code block
                                                break;
                                            case "সর্বমোট:":
                                                // code block
                                                break;
                                            case "পৃষ্ঠাঃ  1/1":
                                                // code block
                                                break;

                                            case "৩- মাস অন্তর মুনাফাভিত্তিক সঞ্চয়পত্র":
                                                // code block
                                                sSPTypeID = "3MS";
                                                break;
                                            case "৫-বছর মেয়াদী বাংলাদেশ সঞ্চয়পত্র":
                                                // code block
                                                sSPTypeID = "3MS";
                                                break;
                                            case "পরিবার সঞ্চয়পত্র":
                                                // code block
                                                sSPTypeID = "FSP";
                                                break;
                                            case "আসল":
                                                sPaymentType = "Principle";
                                                break;
                                            case "মুনাফা":
                                                sPaymentType = "Interest";
                                                break;

                                            default:
                                                //code block
                                                if (i == 0)
                                                {
                                                    dt.Rows[dt.Rows.Count - 1][0] = sSPTypeID;
                                                    i++;
                                                    dt.Rows[dt.Rows.Count - 1][1] = sPaymentType;
                                                    i++;
                                                }
                                                dt.Rows[dt.Rows.Count - 1][i] = GetValue(doc, cell);
                                                i++;

                                                if (GetValue(doc, cell).Trim().Length <= 3)
                                                {
                                                    //sSPTypeID = "";
                                                    sPaymentType = "";
                                                }
                                                break;
                                        }
                                    }
                                }
                            }
                            decimal paymentAmount = 0;
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                if (Convert.ToString(dt.Rows[i]["PaymentAmount"]) == "" || Convert.ToString(dt.Rows[i]["PaymentType"]).Length<=3)
                                {

                                    dt.Rows.RemoveAt(i);
                                    i -= 1;
                                }
                                else
                                {
                                    paymentAmount += Convert.ToDecimal(dt.Rows[i]["PaymentAmount"]);
                                }
                            }

                            gvTransactionList.DataSource = dt;
                            gvTransactionList.DataBind();

                            txtNoofTXN.Text = dt.Rows.Count.ToString();
                            txtTotalTxnAmount.Text = paymentAmount.ToString("N2");

                            Session[Constants.SES_TRANSACTION_UPLOAD] = dt;
                        }
                        else
                        {
                            lFileStatus.ForeColor = System.Drawing.Color.Red;
                            lFileStatus.Text = "Select Only Excel File having extension .xlsx or .xls "; // if file is other than speified extension   
                        }
                        result = true;
                    }
                    catch (Exception ex)
                    {
                        lFileStatus.ForeColor = System.Drawing.Color.Red;
                        lFileStatus.Text = "Error: " + ex.Message.ToString();
                    }
                }
            return result;
        }
        private bool Upload_Encashment()
        {
            lFileStatus.Visible = true;
            bool result = false;
            string filePath = FileUpload1.PostedFile.FileName; // getting the file path of uploaded file  
            string filename1 = Path.GetFileName(filePath); // getting the file name of uploaded file  
            string ext = Path.GetExtension(filename1); // getting the file extension of uploaded file  
            string type = System.String.Empty;
            if (!FileUpload1.HasFile)
            {
                lFileStatus.Text = "Please Select File"; //if file uploader has no file selected  
            }
            else
                if (FileUpload1.HasFile)
                {
                    try
                    {
                        switch (ext) // this switch code validate the files which allow to upload only excel file you can change it for any file  
                        {
                            case ".xls":
                                type = "application/vnd.ms-excel";
                                break;
                            case ".xlsx":
                                type = "application/vnd.ms-excel";
                                break;
                        }
                        if (type != System.String.Empty)
                        {
                            StringBuilder sb = new StringBuilder();
                            try
                            {
                                sb.AppendFormat(" Uploading file: {0}", FileUpload1.FileName);

                                //saving the file
                                FileUpload1.SaveAs(System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath + "\\" + FileUpload1.FileName);
                                //Showing the file information
                                sb.AppendFormat("<br/> Save As: {0}", FileUpload1.PostedFile.FileName);
                                sb.AppendFormat("<br/> File type: {0}", FileUpload1.PostedFile.ContentType);
                                sb.AppendFormat("<br/> File length: {0}", FileUpload1.PostedFile.ContentLength);
                                sb.AppendFormat("<br/> File name: {0}", FileUpload1.PostedFile.FileName);

                            }
                            catch (Exception ex)
                            {
                                sb.Append("<br/> Error <br/>");
                                sb.AppendFormat("Unable to save file <br/> {0}", ex.Message);
                                lFileStatus.Text = sb.ToString();
                            }
                            lFileStatus.Text = sb.ToString();

                            //return;

                            filePath = System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath + "\\" + FileUpload1.FileName;

                            //Stream fStream = FileUpload1.PostedFile.InputStream;
                            lFileStatus.ForeColor = System.Drawing.Color.Green;
                            lFileStatus.Text = "File Uploaded Successfully";

                            //Open the Excel file in Read Mode using OpenXml.
                            // Open the document for editing.

                            SpreadsheetDocument doc = SpreadsheetDocument.Open(filePath, false);

                            //Read the first Sheet from Excel file.
                            Sheet sheet = doc.WorkbookPart.Workbook.Sheets.GetFirstChild<Sheet>();

                            //Get the Worksheet instance.
                            Worksheet worksheet = (doc.WorkbookPart.GetPartById(sheet.Id.Value) as WorksheetPart).Worksheet;

                            //Fetch all the rows present in the Worksheet.
                            IEnumerable<Row> rows = worksheet.GetFirstChild<SheetData>().Descendants<Row>();

                            //Create a new DataTable.
                            DataTable dt = new DataTable();

                            //Loop through the Worksheet rows.
                            string sSPTypeID = "";
                            string sPaymentType = "Encashment";
                            foreach (Row row in rows)
                            {
                                //Use the first row to add columns to DataTable.
                                if (row.RowIndex.Value == 1)
                                {
                                    dt.Columns.Add("SPTypeID");
                                    dt.Columns.Add("PaymentType");
                                    dt.Columns.Add("RegistrationNo");
                                    dt.Columns.Add("IssueName");
                                    dt.Columns.Add("NIDName");
                                    dt.Columns.Add("BankDetails");
                                    dt.Columns.Add("IssueDate");
                                    dt.Columns.Add("NomineeName");
                                    dt.Columns.Add("IssueAmount");
                                    dt.Columns.Add("MaturityDate");
                                    dt.Columns.Add("PaymentDate");
                                    dt.Columns.Add("PaymentAmount");
                                    //foreach (Cell cell in row.Descendants<Cell>())
                                    //{
                                    //dt.Columns.Add(GetValue(doc, cell));
                                    //}
                                }
                                else
                                {
                                    //Add rows to DataTable.
                                    if (sSPTypeID != "" && sPaymentType != "")
                                    {
                                        dt.Rows.Add();
                                    }
                                    int i = 0;
                                    foreach (Cell cell in row.Descendants<Cell>())
                                    {
                                        switch (GetValue(doc, cell))
                                        {
                                            case "উপমোট- মোট  - পরিবার সঞ্চয়পত্র :":
                                                // code block
                                                break;
                                            case "উপমোট- ৩- মাস অন্তর মুনাফাভিত্তিক সঞ্চয়পত্র :":
                                                // code block
                                                break;
                                            case "মোট:":
                                                // code block
                                                break;
                                            case "পৃষ্ঠাঃ  1/1":
                                                // code block
                                                break;

                                            case "৩- মাস অন্তর মুনাফাভিত্তিক সঞ্চয়পত্র":
                                                // code block
                                                sSPTypeID = "3MS";
                                                break;
                                            case "৫-বছর মেয়াদী বাংলাদেশ সঞ্চয়পত্র":
                                                // code block
                                                sSPTypeID = "3MS";
                                                break;
                                            case "পরিবার সঞ্চয়পত্র":
                                                // code block
                                                sSPTypeID = "FSP";
                                                break;
                                            default:
                                                //code block
                                                if (i == 0)
                                                {
                                                    dt.Rows[dt.Rows.Count - 1][0] = sSPTypeID;
                                                    i++;
                                                    dt.Rows[dt.Rows.Count - 1][1] = sPaymentType;
                                                    i++;
                                                }
                                                dt.Rows[dt.Rows.Count - 1][i] = GetValue(doc, cell);
                                                i++;

                                                if (GetValue(doc, cell).Trim().Substring(0, 4) == "উপমোট")
                                                {
                                                    sSPTypeID = "";
                                                }
                                                break;
                                        }
                                    }
                                }
                            }


                            dt.Columns.RemoveAt(5);
                            dt.Columns.RemoveAt(1);

                            decimal paymentAmount = 0;
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                if (Convert.ToString(dt.Rows[i]["PaymentAmount"]) == "")
                                {
                                    dt.Rows.RemoveAt(i);
                                    i -= 1;
                                }
                                else
                                {
                                    paymentAmount += Convert.ToDecimal(dt.Rows[i]["PaymentAmount"]);
                                }
                            }

                            gvTransactionList.DataSource = dt;
                            gvTransactionList.DataBind();

                            txtNoofTXN.Text = dt.Rows.Count.ToString();
                            txtTotalTxnAmount.Text = paymentAmount.ToString("N2");

                            Session[Constants.SES_TRANSACTION_UPLOAD] = dt;
                        }
                        else
                        {
                            lFileStatus.ForeColor = System.Drawing.Color.Red;
                            lFileStatus.Text = "Select Only Excel File having extension .xlsx or .xls "; // if file is other than speified extension   
                        }
                        result = true;
                    }
                    catch (Exception ex)
                    {
                        lFileStatus.ForeColor = System.Drawing.Color.Red;
                        lFileStatus.Text = "Error: " + ex.Message.ToString();
                    }
                }
            return result;
        }
        private string GetValue(SpreadsheetDocument doc, Cell cell)
        {
            string value = cell.CellValue.InnerText;
            if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
            {
                return doc.WorkbookPart.SharedStringTablePart.SharedStringTable.ChildElements.GetItem(int.Parse(value)).InnerText;
            }
            return value;
        }

        protected void gvTransactionList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvTransactionList.PageIndex = e.NewPageIndex;
            if (Session[Constants.SES_TRANSACTION_UPLOAD] != null)
            {
                DataTable dtTmpList = (DataTable)Session[Constants.SES_TRANSACTION_UPLOAD];
                gvTransactionList.DataSource = dtTmpList;
                gvTransactionList.DataBind();
            }
        }
    }

}
