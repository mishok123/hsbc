﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SBM_BLC1.Common;
using SBM_BLC1.DAL.Claim;
using SBM_BLC1.Entity.Common;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Text;
using SBM_BLC1.Configuration;

namespace SBM_WebUI.mp
{
    public partial class SPOnlineRateUpload : System.Web.UI.Page
    {
        #region Local Variable

        CryptographyManager oCrypManager = new CryptographyManager();
        public const string OBJ_PAGE_ID = "sPageID";
        #endregion Local Variable


        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session[Constants.SES_USER_CONFIG] != null)
            {
                if (!Page.IsPostBack)
                {
                    Util.InvalidateSession();
                    InitializeData();
                    //This is for Page Permission
                    CheckPermission chkPer = new CheckPermission();
                    Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];
                    if (!chkPer.CheckPagePermission((System.Web.UI.Control)this.Page, oConfig, (int)Constants.PAGEINDEX_CONFIG.SP_TYPE))
                    {
                        Response.Redirect(Constants.PAGE_ERROR, false);
                    }
                }
            }
            else
            {
                Response.Redirect(Constants.PAGE_LOGIN, false);
            }
        }

        protected void InitializeData()
        {
            Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];

            lFileStatus.ForeColor = System.Drawing.Color.Black;

            txtEffectiveDate.Text = DateTime.Today.ToString(Constants.DATETIME_FORMAT);
            txtUploadDate.Text = DateTime.Today.ToString(Constants.DATETIME_FORMAT);

            DataTable dt1 = new DataTable();

            SPPolicyDAL oSPPolicyDAL = new SPPolicyDAL();
            Result oResult = new Result();

            oResult = oSPPolicyDAL.Get_SPOnlineRate_Tmp();

            if (oResult.Status)
            {
                dt1 = (DataTable)oResult.Return;
                if (dt1.Rows.Count > 0)
                {
                    txtEffectiveDate.Text = Convert.ToDateTime(dt1.Rows[0]["EffectiveDate"]).ToString(Constants.DATETIME_FORMAT);
                    txtUploadDate.Text = Convert.ToDateTime(dt1.Rows[0]["UploadDate"]).ToString(Constants.DATETIME_FORMAT);

                }
            }

            txtNoofTXN.Text = dt1.Rows.Count.ToString();

            Session[Constants.SES_RATE_UPLOAD] = dt1;

            gvRateList.DataSource = dt1;
            gvRateList.DataBind();

        string sPageID = Request.QueryString[OBJ_PAGE_ID];
        

        if (!string.IsNullOrEmpty(sPageID))
        {
            sPageID = oCrypManager.GetDecryptedString(sPageID, Constants.CRYPT_PASSWORD_STRING).Trim();
        }

        if (!string.IsNullOrEmpty(sPageID))
        {
            btnApprove.Visible=true;
            btnSave.Visible = false;
            btnReset.Visible = false;
            btnDelete.Visible = false;
            btnUploadFile.Enabled = false;
            FileUpload1.Enabled = false;
            txtEffectiveDate.Enabled = false;

            #region User-Detail.
            UserDetails oUserDetails = ucUserDet.UserDetail;
            oUserDetails.CheckerID = oConfig.UserName;
            oUserDetails.CheckDate = DateTime.Now;
            ucUserDet.UserDetail = oUserDetails;
            #endregion User-Detail.

        }
        else
        {
            btnApprove.Visible = false;
            btnSave.Visible = true;
            btnReset.Visible = true;
            btnDelete.Visible = true;
            btnUploadFile.Enabled = true;
            FileUpload1.Enabled = true;
            txtEffectiveDate.Enabled = true;
            #region User-Detail.
            UserDetails oUserDetails = new UserDetails();
            oUserDetails.MakerID = oConfig.UserName;
            oUserDetails.MakeDate = DateTime.Now;
            ucUserDet.UserDetail = oUserDetails;
            #endregion User-Detail.
        }

        }

        protected void btnUploadFile_Click(object sender, EventArgs e)
        {
            if (ddlFileTpe.SelectedValue == "Rate")
            {
                Upload_Rate();
            }
        }
        private bool Upload_Rate()
        {
            lFileStatus.Visible = true;
            bool result = false;
            string filePath = FileUpload1.PostedFile.FileName; // getting the file path of uploaded file  
            string filename1 = Path.GetFileName(filePath); // getting the file name of uploaded file  
            string ext = Path.GetExtension(filename1); // getting the file extension of uploaded file  
            string type = System.String.Empty;
            if (!FileUpload1.HasFile)
            {
                lFileStatus.Text = "Please Select File"; //if file uploader has no file selected  
            }
            else
                if (FileUpload1.HasFile)
                {
                    try
                    {
                        switch (ext) // this switch code validate the files which allow to upload only excel file you can change it for any file  
                        {
                            case ".xls":
                                type = "application/vnd.ms-excel";
                                break;
                            case ".xlsx":
                                type = "application/vnd.ms-excel";
                                break;
                        }
                        if (type != System.String.Empty)
                        {
                            StringBuilder sb = new StringBuilder();
                            try
                            {
                                sb.AppendFormat(" Uploading file: {0}", FileUpload1.FileName);

                                //saving the file
                                FileUpload1.SaveAs(System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath + "\\" + FileUpload1.FileName);
                                //Showing the file information
                                sb.AppendFormat("<br/> Save As: {0}", FileUpload1.PostedFile.FileName);
                                sb.AppendFormat("<br/> File type: {0}", FileUpload1.PostedFile.ContentType);
                                sb.AppendFormat("<br/> File length: {0}", FileUpload1.PostedFile.ContentLength);
                                sb.AppendFormat("<br/> File name: {0}", FileUpload1.PostedFile.FileName);

                            }
                            catch (Exception ex)
                            {
                                sb.Append("<br/> Error <br/>");
                                sb.AppendFormat("Unable to save file <br/> {0}", ex.Message);
                                lFileStatus.Text = sb.ToString();
                            }
                            lFileStatus.Text = sb.ToString();

                            //return;

                            filePath = System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath + "\\" + FileUpload1.FileName;

                            //Stream fStream = FileUpload1.PostedFile.InputStream;
                            lFileStatus.ForeColor = System.Drawing.Color.Green;
                            lFileStatus.Text = "Online Rate File Uploaded Successfully";

                            //Open the Excel file in Read Mode using OpenXml.
                            // Open the document for editing.

                            SpreadsheetDocument doc = SpreadsheetDocument.Open(filePath, false);

                            //Read the first Sheet from Excel file.
                            Sheet sheet = doc.WorkbookPart.Workbook.Sheets.GetFirstChild<Sheet>();

                            //Get the Worksheet instance.
                            Worksheet worksheet = (doc.WorkbookPart.GetPartById(sheet.Id.Value) as WorksheetPart).Worksheet;

                            //Fetch all the rows present in the Worksheet.
                            IEnumerable<Row> rows = worksheet.GetFirstChild<SheetData>().Descendants<Row>();

                            //Create a new DataTable.
                            DataTable dt = new DataTable();

                            foreach (Row row in rows)
                            {
                                //Use the first row to add columns to DataTable.
                                if (row.RowIndex.Value == 1)
                                {
                                    dt.Columns.Add("SPTypeID");
                                    dt.Columns.Add("Limit");
                                    dt.Columns.Add("FromMonth");
                                    dt.Columns.Add("ToMonth");
                                    dt.Columns.Add("Rate");
                                    dt.Columns.Add("UploadDate");
                                    dt.Columns.Add("EffectiveDate");
                                    //foreach (Cell cell in row.Descendants<Cell>())
                                    //{
                                    //dt.Columns.Add(GetValue(doc, cell));
                                    //}
                                }
                                else
                                {
                                    int i = 0;
                                    dt.Rows.Add();
                                    foreach (Cell cell in row.Descendants<Cell>())
                                    {
                                        if (i == 4)
                                        {
                                            dt.Rows[dt.Rows.Count - 1][i] = Convert.ToDecimal(GetValue(doc, cell)).ToString("N2");
                                        }
                                        else
                                        {
                                            dt.Rows[dt.Rows.Count - 1][i] = GetValue(doc, cell);
                                        }
                                        
                                        i++;
                                                
                                    }
                                }
                            }

                            for (int i = 0; i < dt.Rows.Count - 1; i++)
                            {
                                dt.Rows[i]["UploadDate"] = SBM_BLC1.Common.Date.GetDateTimeByString(txtUploadDate.Text).ToString("dd-MMM-yyyy");
                                dt.Rows[i]["EffectiveDate"] = SBM_BLC1.Common.Date.GetDateTimeByString(txtEffectiveDate.Text).ToString("dd-MMM-yyyy"); 
                            }
                            gvRateList.DataSource = dt;
                            gvRateList.DataBind();

                            txtNoofTXN.Text = dt.Rows.Count.ToString();

                            Session[Constants.SES_RATE_UPLOAD] = dt;
                        }
                        else
                        {
                            lFileStatus.ForeColor = System.Drawing.Color.Red;
                            lFileStatus.Text = "Select Only Excel File having extension .xlsx or .xls "; // if file is other than speified extension   
                        }
                        result = true;
                    }
                    catch (Exception ex)
                    {
                        lFileStatus.ForeColor = System.Drawing.Color.Red;
                        lFileStatus.Text = ex.Message; // if file is other than speified extension 
                    }
                }
            return result;
        }

        private string GetValue(SpreadsheetDocument doc, Cell cell)
        {
            string value = cell.CellValue.InnerText;
            if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
            {
                return doc.WorkbookPart.SharedStringTablePart.SharedStringTable.ChildElements.GetItem(int.Parse(value)).InnerText;
            }
            return value;
        }

        protected void gvRateList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvRateList.PageIndex = e.NewPageIndex;
            if (Session[Constants.SES_RATE_UPLOAD] != null)
            {
                DataTable dtTmpList = (DataTable)Session[Constants.SES_RATE_UPLOAD];
                gvRateList.DataSource = dtTmpList;
                gvRateList.DataBind();
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (Session[Constants.SES_RATE_UPLOAD] != null)
            {
                DataTable dtTmpList = (DataTable)Session[Constants.SES_RATE_UPLOAD];
                if (dtTmpList.Rows.Count > 0)
                {
                    SPPolicyDAL oSPPolicyDAL = new SPPolicyDAL();
                    oSPPolicyDAL.Save_OnlineRate(dtTmpList, ucUserDet.UserDetail.MakerID , DateTime.Now);
                    lFileStatus.ForeColor = System.Drawing.Color.Green;
                    lFileStatus.Text = "Online Rate save successfully";
                }
            }
            }
            catch (Exception ex)
            {

                lFileStatus.ForeColor = System.Drawing.Color.Red;
                lFileStatus.Text = ex.Message; 
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                SPPolicyDAL oSPPolicyDAL = new SPPolicyDAL();
                oSPPolicyDAL.Delete_OnlineRate();
                InitializeData();
            }
            catch (Exception ex)
            {

                lFileStatus.ForeColor = System.Drawing.Color.Red;
                lFileStatus.Text = ex.Message;
            }

        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                InitializeData();
            }
            catch (Exception ex)
            {

                lFileStatus.ForeColor = System.Drawing.Color.Red;
                lFileStatus.Text = ex.Message;
            }

        }

        protected void btnApprove_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dtTmpList = (DataTable)Session[Constants.SES_RATE_UPLOAD];
                if (dtTmpList.Rows.Count > 0)
                {
                    SPPolicyDAL oSPPolicyDAL = new SPPolicyDAL();
                    oSPPolicyDAL.Approve_OnlineRate( ucUserDet.UserDetail.CheckerID, DateTime.Now);
                    lFileStatus.ForeColor = System.Drawing.Color.Green;
                    lFileStatus.Text = "Online Rate approved successfully";
                }
            }
            catch (Exception ex)
            {

                lFileStatus.ForeColor = System.Drawing.Color.Red;
                lFileStatus.Text = ex.Message;
            }

        }
    }

}
